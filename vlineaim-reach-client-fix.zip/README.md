# VLine Aim Reach Add-on — client + server fix

Target: Minecraft Java 26.1.2, Fabric Loader, Java 25.

## What changed

The previous build only applied reach attributes on the server player. This version applies the same attribute modifiers to both the local client player and the server player. The client-side part updates crosshair/selection reach; the server-side part validates the same reach in worlds/servers that have this add-on installed.

Default survival values are intended to be:
- Entity interaction range: 3.0 + 2.0 = 5.0 blocks
- Block interaction range: 4.5 + 2.0 = 6.5 blocks

## Important

- This is a new source project; it is not a ready-made compiled JAR. Build it using GitHub Actions below.
- For single-player, the mod runs the client and integrated-server parts in the same modded game.
- For multiplayer, the server must also install the add-on. Client-only changes do not override a server's interaction validation.
- Only use extended reach in worlds/servers where it is allowed.

## GitHub Actions

Upload this ZIP to the root of the existing repository, keeping the `build.yml` workflow under `.github/workflows/`. Run the **Build VLine Aim Reach Add-on** workflow. On success, download the artifact named `vlineaim-reach-minecraft-26.1.2`. It contains the add-on JAR, the supplied VLine Aim reference JAR, and a combined install bundle.

## Testing

1. Remove older `vlineaim-reach-addon-*.jar` files to avoid duplicates.
2. Install the newly built add-on JAR and the VLine Aim JAR in the same 26.1.2 Fabric instance.
3. Create a single-player Survival world and test targeting a mob at about 4 blocks and interacting with a block at about 5.5–6 blocks.
4. Check `.minecraft/logs/latest.log` for `VLine Aim Reach client component initialized` and `VLine Aim Reach active locally`.

If the logged values do not show the increased range, send the relevant `latest.log` lines. If values are increased but multiplayer interactions fail, the server is rejecting the extra reach and needs the add-on too.
