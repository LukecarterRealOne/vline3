package com.vlineaim.reach;

import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.minecraft.client.player.LocalPlayer;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

/** Client-side half: extends local targeting/selection reach so the crosshair can select at distance. */
public final class VLineAimReachClient implements ClientModInitializer {
    private static final Logger LOGGER = LoggerFactory.getLogger("vlineaim_reach");
    private static boolean loggedForCurrentConnection;

    @Override
    public void onInitializeClient() {
        LOGGER.info("VLine Aim Reach client component initialized.");
        ClientTickEvents.END_CLIENT_TICK.register(client -> {
            LocalPlayer player = client.player;
            if (player == null) {
                loggedForCurrentConnection = false;
                return;
            }

            ReachModifiers.apply(player);
            if (!loggedForCurrentConnection) {
                LOGGER.info("VLine Aim Reach active locally: entity range {} blocks, block range {} blocks. " +
                                "A multiplayer server must install this add-on too to accept extended interactions.",
                        player.getAttributeValue(net.minecraft.world.entity.ai.attributes.Attributes.ENTITY_INTERACTION_RANGE),
                        player.getAttributeValue(net.minecraft.world.entity.ai.attributes.Attributes.BLOCK_INTERACTION_RANGE));
                loggedForCurrentConnection = true;
            }
        });
    }
}
