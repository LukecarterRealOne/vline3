package com.vlineaim.reach;

import net.minecraft.core.Holder;
import net.minecraft.resources.Identifier;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.ai.attributes.Attribute;
import net.minecraft.world.entity.ai.attributes.AttributeInstance;
import net.minecraft.world.entity.ai.attributes.AttributeModifier;
import net.minecraft.world.entity.ai.attributes.Attributes;

/** Shared reach modifiers applied on both the logical client and server. */
public final class ReachModifiers {
    // Survival defaults: entity 3.0 -> 5.0 blocks; block 4.5 -> 6.5 blocks.
    // These modest values are intentionally visible during a local survival test.
    public static final double ENTITY_REACH_BONUS = 2.0;
    public static final double BLOCK_REACH_BONUS = 2.0;

    private static final Identifier ENTITY_REACH_ID =
            Identifier.fromNamespaceAndPath("vlineaim_reach", "entity_reach_bonus");
    private static final Identifier BLOCK_REACH_ID =
            Identifier.fromNamespaceAndPath("vlineaim_reach", "block_reach_bonus");

    private static final AttributeModifier ENTITY_REACH_MODIFIER = new AttributeModifier(
            ENTITY_REACH_ID,
            ENTITY_REACH_BONUS,
            AttributeModifier.Operation.ADD_VALUE
    );
    private static final AttributeModifier BLOCK_REACH_MODIFIER = new AttributeModifier(
            BLOCK_REACH_ID,
            BLOCK_REACH_BONUS,
            AttributeModifier.Operation.ADD_VALUE
    );

    private ReachModifiers() {}

    public static void apply(LivingEntity entity) {
        ensureModifier(entity, Attributes.ENTITY_INTERACTION_RANGE, ENTITY_REACH_MODIFIER);
        ensureModifier(entity, Attributes.BLOCK_INTERACTION_RANGE, BLOCK_REACH_MODIFIER);
    }

    private static void ensureModifier(
            LivingEntity entity,
            Holder<Attribute> attribute,
            AttributeModifier modifier
    ) {
        AttributeInstance instance = entity.getAttribute(attribute);
        if (instance != null && !instance.hasModifier(modifier.id())) {
            instance.addTransientModifier(modifier);
        }
    }
}
