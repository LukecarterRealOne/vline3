package com.vlineaim.reach;

import net.fabricmc.api.ModInitializer;
import net.fabricmc.fabric.api.event.lifecycle.v1.ServerTickEvents;
import net.minecraft.server.level.ServerPlayer;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

/** Server-side half: the server must apply the same range when validating interactions. */
public final class VLineAimReachAddon implements ModInitializer {
    private static final Logger LOGGER = LoggerFactory.getLogger("vlineaim_reach");

    @Override
    public void onInitialize() {
        LOGGER.info("VLine Aim Reach server component initialized (entity +2.0, block +2.0).");
        ServerTickEvents.END_SERVER_TICK.register(server -> {
            for (ServerPlayer player : server.getPlayerList().getPlayers()) {
                ReachModifiers.apply(player);
            }
        });
    }
}
